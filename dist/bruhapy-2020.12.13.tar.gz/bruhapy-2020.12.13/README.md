# bruhapy
An API wrapper for bruhapi.xyz

This is a simple synchronous API wrapper for [bruhapi.xyz](https://bruhapi.xyz). It is currently incomplete, but I am accepting PR's if you would like to contribute.

## TODO
- [ ] Finish the Text Endpoints
- [ ] Add more errors
- [x] At least I started ok?
